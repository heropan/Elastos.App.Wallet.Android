export const en = {
  'welcome': 'welcome to this app',
  'hello': 'Hola'
};
