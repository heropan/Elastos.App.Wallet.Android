cordova.define("ElaWallet.Wallet", function(require, exports, module) {
var exec = require('cordova/exec');

// exports.coolMethod = function (arg0, success, error) {
//     exec(success, error, 'Wallet', 'coolMethod', [arg0]);
// };


var walletFunc = function(){};


walletFunc.prototype.print = function(arg0, success, error) {
    exec(success, error, "Wallet", "print", arg0);
};


walletFunc.prototype.recoverWallet = function(arg0, success, error) {
  exec(success, error, "Wallet", "recoverWallet", arg0);
};

walletFunc.prototype.createWallet = function(arg0, success, error) {
  exec(success, error, "Wallet", "createWallet", arg0);
};

walletFunc.prototype.start = function(arg0, success, error) {
  exec(success, error, "Wallet", "start", arg0);
};

walletFunc.prototype.stop = function(arg0, success, error) {
  exec(success, error, "Wallet", "stop", arg0);
};

walletFunc.prototype.exportKey = function(arg0, success, error) {
  exec(success, error, "Wallet", "exportKey", arg0);
};

walletFunc.prototype.importKey = function(arg0, success, error) {
  exec(success, error, "Wallet", "importKey", arg0);
};

walletFunc.prototype.createTransaction = function(arg0, success, error) {
  exec(success, error, "Wallet", "createTransaction", arg0);
};

walletFunc.prototype.getMnemonic = function(arg0, success, error) {
  exec(success, error, "Wallet", "getMnemonic", arg0);
};

walletFunc.prototype.getTransactions = function(arg0, success, error) {
  exec(success, error, "Wallet", "getTransactions", arg0);
};

walletFunc.prototype.registerWalletListener = function(arg0, success, error) {
  exec(success, error, "Wallet", "registerWalletListener", arg0);
};
walletFunc.prototype.getBalance = function(arg0, success, error) {
  exec(success, error, "Wallet", "getBalance", arg0);
};

walletFunc.prototype.createAddress = function(arg0, success, error) {
  exec(success, error, "Wallet", "createAddress", arg0);
};

walletFunc.prototype.getAddressList = function(arg0, success, error) {
  exec(success, error, "Wallet", "getAddressList", arg0);
};

walletFunc.prototype.sign = function(arg0, success, error) {
  exec(success, error, "Wallet", "sign", arg0);
};


walletFunc.prototype.getPubKey = function(arg0, success, error) {
  exec(success, error, "Wallet", "getPubKey", arg0);
};


var WALLETFUNC = new walletFunc();
module.exports = WALLETFUNC;

});
